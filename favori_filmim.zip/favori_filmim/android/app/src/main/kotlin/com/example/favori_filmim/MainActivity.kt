package com.example.favori_filmim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
