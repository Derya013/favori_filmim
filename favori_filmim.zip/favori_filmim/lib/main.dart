import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green[800],
          title: Center(child: Text('Favori Filmim')),
        ),
        body: Stack(
          children: [
            // Arka plan resmi
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                      'images/matrixbackground.jpg'), // Arka plan resmi
                  fit: BoxFit.cover,
                ),
              ),
            ),
            // Üstteki resim
            Center(
              child: Image.asset('images/matrix.jpg'), // Üstteki resim
            ),
          ],
        ),
      ),
    ),
  );
}
